<?php
//000000086400
 exit();?>
a:1:{i:0;a:4:{s:2:"id";i:104;s:4:"name";s:7:"banenr2";s:3:"url";s:27:"/pages/pink-list/index?id=2";s:3:"pic";s:74:"http://datong.crmeb.net/public/uploads/attach/2019/03/29/5c9e015bdc6f5.jpg";}}