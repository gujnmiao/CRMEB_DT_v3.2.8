<?php /*a:6:{s:82:"/Users/mimiao/www/wwwroot/CRMEB_DT_v3.2.8/app/admin/view/article/article/index.php";i:1595820902;s:77:"/Users/mimiao/www/wwwroot/CRMEB_DT_v3.2.8/app/admin/view/public/container.php";i:1595820902;s:78:"/Users/mimiao/www/wwwroot/CRMEB_DT_v3.2.8/app/admin/view/public/frame_head.php";i:1595820902;s:73:"/Users/mimiao/www/wwwroot/CRMEB_DT_v3.2.8/app/admin/view/public/style.php";i:1595820902;s:78:"/Users/mimiao/www/wwwroot/CRMEB_DT_v3.2.8/app/admin/view/public/inner_page.php";i:1595820902;s:80:"/Users/mimiao/www/wwwroot/CRMEB_DT_v3.2.8/app/admin/view/public/frame_footer.php";i:1595820902;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php if(empty($is_layui) || (($is_layui instanceof \think\Collection || $is_layui instanceof \think\Paginator ) && $is_layui->isEmpty())): ?>
    <link href="/system/frame/css/bootstrap.min.css?v=3.4.0" rel="stylesheet">
    <?php endif; ?>
    <link href="/static/plug/layui/css/layui.css" rel="stylesheet">
    <link href="/system/css/layui-admin.css" rel="stylesheet">
    <link href="/system/frame/css/font-awesome.min.css?v=4.3.0" rel="stylesheet">
    <link href="/system/frame/css/animate.min.css" rel="stylesheet">
    <link href="/system/frame/css/style.min.css?v=3.0.0" rel="stylesheet">
    <script src="/system/frame/js/jquery.min.js"></script>
    <script src="/system/frame/js/bootstrap.min.js"></script>
    <script src="/static/plug/layui/layui.all.js"></script>
    <script>
        $eb = parent._mpApi;
        window.controlle="<?php echo strtolower(trim(preg_replace("/[A-Z]/", "_\\0", app('request')->controller()), "_"));?>";
        window.module="<?php echo app('http')->getName();?>";
    </script>



    <title></title>
    
<link href="/system/module/wechat/news/css/index.css" type="text/css" rel="stylesheet">

    <!--<script type="text/javascript" src="/static/plug/basket.js"></script>-->
<script type="text/javascript" src="/static/plug/requirejs/require.js"></script>
<?php /*  <script type="text/javascript" src="/static/plug/requirejs/require-basket-load.js"></script>  */ ?>
<script>
    var hostname = location.hostname;
    if(location.port) hostname += ':' + location.port;
    requirejs.config({
        map: {
            '*': {
                'css': '/static/plug/requirejs/require-css.js'
            }
        },
        shim:{
            'iview':{
                deps:['css!iviewcss']
            },
            'layer':{
                deps:['css!layercss']
            }
        },
        baseUrl:'//'+hostname+'/',
        paths: {
            'static':'static',
            'system':'system',
            'vue':'static/plug/vue/dist/vue.min',
            'axios':'static/plug/axios.min',
            'iview':'static/plug/iview/dist/iview.min',
            'iviewcss':'static/plug/iview/dist/styles/iview',
            'lodash':'static/plug/lodash',
            'layer':'static/plug/layer/layer',
            'layercss':'static/plug/layer/theme/default/layer',
            'jquery':'static/plug/jquery/jquery.min',
            'moment':'static/plug/moment',
            'sweetalert':'static/plug/sweetalert2/sweetalert2.all.min',
            'formCreate':'/static/plug/form-create/form-create.min',

        },
        basket: {
            excludes:['system/js/index','system/util/mpVueComponent','system/util/mpVuePackage']
//            excludes:['system/util/mpFormBuilder','system/js/index','system/util/mpVueComponent','system/util/mpVuePackage']
        }
    });
</script>
<script type="text/javascript" src="/system/util/mpFrame.js"></script>
    
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">

<style>
    tr td img{height: 50px;}
</style>
<div class="row">
    <div class="col-sm-3">
      	<div class="ibox">
           	<div class="ibox-title">分类</div>
      		<div class="ibox-content">
            <ul  class="folder-list m-b-md">
              	<?php if(is_array($tree) || $tree instanceof \think\Collection || $tree instanceof \think\Paginator): $i = 0; $__LIST__ = $tree;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                   <li class="p-xxs"><a href="<?php echo Url('article.article/index',array('pid'=>$vo['id'])); ?>"><?php echo htmlentities($vo['html']); ?><?php echo htmlentities($vo['title']); ?></a></li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
          	</div>
        </div>
    </div>
    <div class="col-sm-9 m-l-n-md">
        <div class="ibox">
            <div class="ibox-title">
                <button type="button" class="btn btn-w-m btn-primary" onclick="$eb.createModalFrame(this.innerText,'<?php echo Url('create',array('cid'=>$where['cid'])); ?>',{w:1100,h:760})">添加文章</button>
                <div style="margin-top: 2rem"></div>
                <div class="row">
                    <div class="m-b m-l">
                        <form action="" class="form-inline">

                            <div class="input-group">
                                <input type="text" name="title" value="<?php echo htmlentities($where['title']); ?>" placeholder="请输入关键词" class="input-sm form-control"> <span class="input-group-btn"><button type="submit" class="btn btn-sm btn-primary"> <i class="fa fa-search" ></i>搜索</button> </span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="ibox-content">
                <table class="footable table table-striped  table-bordered " data-page-size="20">
                    <thead>
                    <tr>
                        <th class="text-center" width="5%">id</th>
                        <th class="text-center" width="10%">图片</th>
                        <th class="text-left" >[分类]标题</th>
                        <th class="text-center" width="8%">浏览量</th>
                        <th class="text-center">关联标题</th>
                        <th class="text-center" width="15%">添加时间</th>
                        <th class="text-center" width="20%">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr>
                        <td><?php echo htmlentities($vo['id']); ?></td>
                        <td>
                            <img src="<?php echo htmlentities($vo['image_input']); ?>"/>
                        </td>
                        <td>[<?php echo htmlentities($vo['catename']); ?>]<?php echo htmlentities($vo['title']); ?></td>
                        <td><?php echo htmlentities($vo['visit']); ?></td>
                        <td><?php echo htmlentities($vo['store_name']); ?></td>
                        <td><?php echo htmlentities(date("Y-m-d H:i:s",!is_numeric($vo['add_time'])? strtotime($vo['add_time']) : $vo['add_time'])); ?></td>

                        <td class="text-center">
                            <button style="margin-top: 5px;" class="btn btn-info btn-xs" type="button"  onclick="$eb.createModalFrame('编辑','<?php echo Url('create',array('id'=>$vo['id'],'cid'=>$where['cid'])); ?>',{w:1100,h:760})"><i class="fa fa-edit"></i> 编辑</button>
                            <?php if($vo['product_id']): ?>
                            <button style="margin-top: 5px;" class="btn btn-warning btn-xs underline" data-id="<?php echo htmlentities($vo['id']); ?>" type="button" data-url="<?php echo Url('unrelation',array('id'=>$vo['id'])); ?>" ><i class="fa fa-chain-broken"></i> 取消关联</button>
                            <?php else: ?>
                            <button style="margin-top: 5px;" class="btn btn-warning btn-xs openWindow" data-id="<?php echo htmlentities($vo['id']); ?>" type="button" data-url="<?php echo Url('relation',array('id'=>$vo['id'])); ?>" ><i class="fa fa-chain"></i> 关联产品</button>
                            <?php endif; ?>
                            <button  style="margin-top: 5px;" class="btn btn-danger btn-xs del_news_one" data-id="<?php echo htmlentities($vo['id']); ?>" type="button" data-url="<?php echo Url('delete',array('id'=>$vo['id'])); ?>" ><i class="fa fa-times"></i> 删除</button>
                        </td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div style="margin-left: 10px">
            <link href="/system/frame/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
<div class="row">
    <div class="col-sm-6">
        <div class="dataTables_info" id="DataTables_Table_0_info" role="alert" aria-live="polite" aria-relevant="all">共 <?php echo htmlentities($total); ?> 项</div>
    </div>
    <div class="col-sm-6">
        <div class="dataTables_paginate paging_simple_numbers" id="editable_paginate">
            <?php echo $page;?>
        </div>
    </div>
</div>
        </div>
    </div>

</div>




<script>

    $('.del_news_one').on('click',function(){
        window.t = $(this);
        var _this = $(this),url =_this.data('url');
        $eb.$swal('delete',function(){
            $eb.axios.get(url).then(function(res){
                console.log(res);
                if(res.status == 200 && res.data.code == 200) {
                    $eb.$swal('success',res.data.msg);
                    _this.parents('tr').remove();
                }else
                    return Promise.reject(res.data.msg || '删除失败')
            }).catch(function(err){
                $eb.$swal('error',err);
            });
        })
    });

    $('.openWindow').on('click',function () {
        return $eb.createModalFrame('选择产品',$(this).data('url'));
    });

    $('.underline').on('click',function () {
        var url=$(this).data('url');
        $eb.$swal('delete',function(){
            $eb.axios.get(url).then(function(res){
                if(res.status == 200 && res.data.code == 200) {
                    $eb.$swal('success',res.data.msg);
                    window.location.reload();
                }else
                    return Promise.reject(res.data.msg || '取消失败')
            }).catch(function(err){
                $eb.$swal('error',err);
            });
        },{title:'确认取消关联产品？',text:'取消后可再关联页选择产品重新关联',confirm:'确定'})
    })
</script>


</div>
</body>
</html>
