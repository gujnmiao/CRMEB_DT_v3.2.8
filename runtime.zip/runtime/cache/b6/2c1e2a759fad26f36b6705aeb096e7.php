<?php
//000000086400
 exit();?>
a:3:{i:0;a:5:{s:2:"id";i:121;s:4:"info";s:39:"CRMEB电商系统 V 3.0 即将上线！";s:3:"url";s:22:"/pages/news_list/index";s:4:"show";s:1:"2";s:7:"wap_url";s:10:"/news_list";}i:1;a:5:{s:2:"id";i:122;s:4:"info";s:39:"CRMEB电商系统 V 3.0 即将上线！";s:3:"url";s:22:"/pages/news_list/index";s:4:"show";s:1:"2";s:7:"wap_url";s:10:"/news_list";}i:2;a:5:{s:2:"id";i:123;s:4:"info";s:39:"CRMEB电商系统 V 3.0 即将上线！";s:3:"url";s:22:"/pages/news_list/index";s:4:"show";s:1:"2";s:7:"wap_url";s:10:"/news_list";}}