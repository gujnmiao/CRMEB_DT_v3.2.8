<?php
//000000086400
 exit();?>
a:2:{i:0;a:5:{s:2:"id";i:127;s:3:"img";s:74:"http://datong.crmeb.net/public/uploads/attach/2019/04/13/5cb18e247a1a9.jpg";s:7:"comment";s:19:"精品推荐750*282";s:4:"link";s:30:"/pages/first-new-product/index";s:8:"wap_link";s:16:"/hot_new_goods/1";}i:1;a:5:{s:2:"id";i:128;s:3:"img";s:74:"http://datong.crmeb.net/public/uploads/attach/2019/03/29/5c9e015bdc6f5.jpg";s:7:"comment";s:19:"精品推荐750*282";s:4:"link";s:30:"/pages/first-new-product/index";s:8:"wap_link";s:16:"/hot_new_goods/1";}}